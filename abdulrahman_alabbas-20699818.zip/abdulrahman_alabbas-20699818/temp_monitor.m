function temp_monitor(a,duration)
% temp_monitor - Monitors temperature and controls LEDs in real time.
%
% Reads temperature from Arduino, displays it live, and controls LEDs based on:
% - Green: 18–24°C (ON)
% - Yellow: <18°C (Blinks every 0.5s)
% - Red: >24°C (Blinks every 0.25s)

    temperatures = zeros(1, duration);
    time = 0:duration-1;

    figure;
    h = plot(time, temperatures, 'b', 'LineWidth', 2);
    xlabel('Time (s)');
    ylabel('Temperature (°C)');
    title('Real-Time Temp Monitoring');
   
    xlim([0 duration]);

    for i = 1:duration
        voltage = readVoltage(a, 'A0');
        temp = (voltage) * 100;
        temperatures(i) = temp;

        set(h, 'YData', temperatures);
        drawnow;

        % Control on leds 
        if temp < 18
            blinkLED(a, 'D3', 0.5); % Yellow blinking
              writeDigitalPin(a, 'D2', 0);
               writeDigitalPin(a, 'D4', 0);
       elseif  temp  > 24
            blinkLED(a, 'D2', 0.25); % Red blinking
            writeDigitalPin(a, 'D4', 0);
            writeDigitalPin(a, 'D3', 0);
        elseif 18 < temp < 24
            % Green blinking
            writeDigitalPin(a, 'D2', 0);
            writeDigitalPin(a, 'D3', 0);
            writeDigitalPin(a, 'D4', 1);
        end 
     end
end

function blinkLED(a, pin, interval)
    writeDigitalPin(a, pin, 1);
    pause(interval);
    writeDigitalPin(a, pin, 0);
end
