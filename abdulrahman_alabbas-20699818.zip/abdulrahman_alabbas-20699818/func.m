a = arduino('COM4', 'Uno');

duration = 600;


temp_monitor(a, duration);


temp_prediction(a, 300);

disp("Done");