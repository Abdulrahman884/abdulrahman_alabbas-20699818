% abdulrahman_alabbas
% egyaa35@nottingham.ac.uk
% Coursework 2 - MATLAB + Arduino using Arduino Support Package
% task1_temperature_logging.m
% Task 1: Read temperature from the sensor, plot it, and save to a text file

a = arduino('COM4', 'Uno'); % Arduino definition

duration = 600; % 10 minutes
temperatures = zeros(1, duration);
time = 0:duration-1;

figure;
h1 = plot(time, temperatures, 'b', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Temperature (°C)');
title('Task 1 - Cabin Temperature Logging');

xlim([0 duration]);

filename = 'cabin_temperature.txt';
fid = fopen(filename, 'w');
fprintf(fid, 'Data logging initiated - %s\n\n', datestr(now));
fprintf(fid, 'Location - kuwait\n\n');

for i = 1:duration
    voltage = readVoltage(a, 'A0'); % قراءة من حساس MCP9700A
    
    temperature = voltage * 100;
    temperatures(i) = temperature;

    set(h1, 'YData', temperatures);
    drawnow;

    % Writing data insert file
    fprintf(fid, 'Minute\t%d\n', floor(i/60));
    fprintf(fid, 'Temperature\t%.2f C\n\n', temperature);

    pause(1);
end

fprintf(fid, 'Max temp\t%.2f C\n', max(temperatures));
fprintf(fid, 'Min temp\t%.2f C\n', min(temperatures));
fprintf(fid, 'Average temp\t%.2f C\n', mean(temperatures));
fprintf(fid, '\nData logging terminated\n');
fclose(fid);

disp('✅ Task 1 Completed.');
