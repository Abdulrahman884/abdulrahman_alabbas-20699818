function temp_prediction(a, duration)
% temp_prediction - monitors rate of temperature change and predicts future values
%
% This function reads temperature data from Arduino using the analog input,
% calculates the rate of temperature change, and predicts the value after 5 minutes.
% It turns on LEDs accordingly:
% - Green: stable temp
% - Red: rising too fast
% - Yellow: dropping too fast

    temperatures = zeros(1, duration);
    time = 0:duration-1;

    figure;
    h = plot(time, temperatures, 'b', 'LineWidth', 2);
    xlabel('Time (s)');
    ylabel('Temperature (°C)');
    title('Temp Prediction & Rate Monitoring');
    grid on;
  
    xlim([0 duration]);

    for i = 1:duration
        voltage = readVoltage(a, 'A0');
        temperature = voltage * 100;
        temperatures(i) = temperature;

        set(h, 'YData', temperatures);
        drawnow;

        if i > 60
            rate_per_sec = (temperatures(i) - temperatures(i-60)) / 60;
        else
            rate_per_sec = 0;
        end

        predicted = temperature + rate_per_sec * 300;

        fprintf('Time %d s - Temp: %.2f °C | Rate: %.3f °C/s | Predicted: %.2f °C\n', ...
                i, temperature, rate_per_sec, predicted);

        if rate_per_sec > 4/60
            writeDigitalPin(a, 'D2', 1);
            writeDigitalPin(a, 'D3', 0);
            writeDigitalPin(a, 'D4', 0);
        elseif rate_per_sec < -4/60
            writeDigitalPin(a, 'D2', 0);
            writeDigitalPin(a, 'D3', 1);
            writeDigitalPin(a, 'D4', 0);
        else
            writeDigitalPin(a, 'D2', 0);
            writeDigitalPin(a, 'D3', 0);
            writeDigitalPin(a, 'D4', 1);
        end

        pause(1);
    end
end
