% abdulrahman_alabbas
% egyaa35@nottingham.ac.uk
% Coursework 2 - MATLAB + Arduino using Arduino Support Package
% preliminary_task.m
% Task: Test Arduino LED communication using Arduino Support Package

a = arduino('COM4','Uno'); % Arduino definition

% Turn on LED on D4 as test point
writeDigitalPin(a, 'D4', 1);
pause(1);
writeDigitalPin(a, 'D4', 0);
pause(1);

% Turn on flashing LED
for i = 1:5
    writeDigitalPin(a, 'D4', 1);
    pause(0.5);
    writeDigitalPin(a, 'D4', 0);
    pause(0.5);
end

disp('✅ Preliminary Task Completed.');
